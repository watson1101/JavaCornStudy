sealed class Point {}

final class Pointless extends Point {}
