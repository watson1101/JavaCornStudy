@SuppressWarnings("module") 
module v2ch09.exportedpkg
{
   requires com.horstmann.greet;
}
